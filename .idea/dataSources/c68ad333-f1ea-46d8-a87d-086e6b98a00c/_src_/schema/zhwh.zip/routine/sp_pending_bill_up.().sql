CREATE PROCEDURE sp_pending_bill_up()
  BEGIN
START TRANSACTION;
INSERT INTO tb_sp_history_bill (SELECT *,NOW() FROM tb_sp_pending_bill WHERE V_BILL_NO NOT IN (SELECT V_BILL_NO FROM tb_sp_pending_bill_tmp));
DELETE FROM tb_sp_pending_bill WHERE V_BILL_NO NOT IN (SELECT V_BILL_NO FROM tb_sp_pending_bill_tmp);
INSERT INTO tb_sp_pending_bill (SELECT * FROM tb_sp_pending_bill_tmp WHERE V_BILL_NO NOT IN (SELECT V_BILL_NO FROM tb_sp_pending_bill));
DELETE FROM tb_sp_pending_bill_tmp;
COMMIT;
END;
